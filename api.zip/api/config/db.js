import { Sequelize } from "sequelize";
const sequelize = new Sequelize(`mysql://root:NiniKortexdu974@localhost:3306/divertissements`);

export default sequelize;